﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RomanToInteger.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanToInteger.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public static List<string> romanNumerals = new List<string>() { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
        public static List<int> numerals = new List<int>() { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
        public static Dictionary<string, int> patternNumerals = new Dictionary<string, int>();
        public static Dictionary<string, int> _counter = new Dictionary<string, int>();

        [HttpPost]
        public JsonResult ToRomanNumeral(int number)
        {
            try
            {
                var romanNumeral = string.Empty;
                var numberValue = number;
                while (number > 0)
                {
                    // find biggest numeral that is less than equal to number
                    var index = numerals.FindIndex(x => x <= number);
                    // subtract it's value from your number
                    number -= numerals[index];
                    // tack it onto the end of your roman numeral
                    romanNumeral += romanNumerals[index];
                }

                string _found = _counter.Where(x => x.Key == numberValue.ToString()).Select(x => x.Key).FirstOrDefault();
                if (!string.IsNullOrEmpty(_found))
                    _counter[_found] += 1;
                else
                {
                    patternNumerals.Add(romanNumeral, numberValue);
                    _counter[numberValue.ToString()] = 1;
                }
                    


                var response = new
                {
                    res = true,
                    roman = romanNumeral,
                };

                return Json(response);
            }
            catch (Exception ex)
            {

                var response = new
                {
                    res = false,
                    roman = "Got Exception " + ex.Message
                };

                return Json(response);
            }
            
        }

        [HttpPost]
        public JsonResult ToGetTopNumeral(int number)
        {
            try
            {
                var _list = _counter.OrderByDescending(x => x.Value).Select(x => x.Key).Take(5);
                string str = string.Empty;

                foreach (var item in _list)
                {
                    var _itemFound = patternNumerals.Where(x => x.Value.ToString() == item).FirstOrDefault();
                    str = str + " " + _itemFound.Key + " ,";
                }

                if (string.IsNullOrEmpty(str))
                    str = "No Items are found";

                var response = new
                {
                    res = true,
                    roman = str
                };

                return Json(response);
            }
            catch (Exception ex)
            {
                var response = new
                {
                    res = false,
                    roman = "Got Exception " + ex.Message
                };

                return Json(response);
            }
        }
    }
}
